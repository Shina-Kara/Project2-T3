/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.psmanager.Personnel.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Shina
 */
public class PersonnelDBConnect {
    public static Connection derbyConnection() throws SQLException
    {
    String url = "jdbc:derby://localhost:1527/PsManagerDb";
    String username = "Shina";
    String password = "123456";
    return DriverManager.getConnection(url, username, password);
    }
}
