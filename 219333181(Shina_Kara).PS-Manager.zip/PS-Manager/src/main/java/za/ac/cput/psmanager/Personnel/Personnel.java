/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.psmanager.Personnel;

/**
 *
 * @author Shina
 */
public class Personnel {
    
private String idNumber; 
private String name,surname;
private String age, contactNumber, emergencyContact;
private String address;
private String leaveDays,sickDays;

    public Personnel(String idNumber, String name, String surname, String age, String contactNumber, String emergencyContact, String address, String leaveDays, String sickDays) {
        this.idNumber = idNumber;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.contactNumber = contactNumber;
        this.emergencyContact = emergencyContact;
        this.address = address;
        this.leaveDays = leaveDays;
        this.sickDays = sickDays;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getAge() {
        return age;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public String getAddress() {
        return address;
    }

    public String getLeaveDays() {
        return leaveDays;
    }

    public String getSickDays() {
        return sickDays;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLeaveDays(String leaveDays) {
        this.leaveDays = leaveDays;
    }

    public void setSickDays(String sickDays) {
        this.sickDays = sickDays;
    }

    @Override
    public String toString() {
        return "Personnel{" + "idNumber=" + idNumber + ", name=" + name + ", surname=" + surname + ", age=" + age + ", contactNumber=" + contactNumber + ", emergencyContact=" + emergencyContact + ", address=" + address + ", leaveDays=" + leaveDays + ", sickDays=" + sickDays + '}';
    }
  


}
