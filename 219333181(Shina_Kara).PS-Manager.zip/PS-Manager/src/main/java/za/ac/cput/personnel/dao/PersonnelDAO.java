/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.personnel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import za.ac.cput.psmanager.Personnel.connect.PersonnelDBConnect;
import za.ac.cput.psmanager.PsManagerMain;
import za.ac.cput.psmanager.Personnel.Personnel;
/**
 *
 * @author Shina
 */
public class PersonnelDAO {
private final Connection con;
    
  
    public PersonnelDAO() throws SQLException {
        this.con = PersonnelDBConnect.derbyConnection();
   
    }
    //insert
    public Personnel save(Personnel personnel) throws SQLException{
    String insertSQL = "INSERT INTO OfficerDetails (Idnumber,name,surname,age,contactNumber,emergencyContact,address,leavedays,sickdays )"
            + "VALUES (?,?,?,?,?,?,?,?,?)";
    PreparedStatement ps = this.con.prepareStatement(insertSQL);   
    ps.setString(1, personnel.getIdNumber());
    ps.setString(2, personnel.getName());
    ps.setString(3, personnel.getSurname());
    ps.setString(4, personnel.getAge());
    ps.setString(5, personnel.getContactNumber());
    ps.setString(6, personnel.getEmergencyContact());
    ps.setString(7, personnel.getAddress());
    ps.setString(8, personnel.getLeaveDays());
    ps.setString(9, personnel.getSickDays());
    
   

    ps.executeUpdate();
    ps.close();
    return personnel;
    }
    //show all
    public List <Personnel> getAll() throws SQLException{

        String getAll_SQL = "SELECT * FROM OfficerDetails";
        List <Personnel> personnel = new ArrayList<>();
        try (PreparedStatement ps = this.con.prepareStatement(getAll_SQL); ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()){
                String idNumber = rs.getString("idNumber");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String age = rs.getString("Age");
                String contactNumber = rs.getString("Contactnumber");
                String emergencyContact = rs.getString("emergencycontact");
                String address = rs.getString("address");
                String leaveDays = rs.getString("leavedays");
                String sickDays = rs.getString("sickdays");
                
                Personnel Personnel = new Personnel(idNumber, name, surname, age, contactNumber, emergencyContact, address, leaveDays, sickDays);
                personnel.add(Personnel);
        }
        return personnel;
        }
   
        
    }
    //delete
    public void delete(String string){
         String deleteSQL = "DELETE  from OFFICERDETAILS WHERE Idnumber = ? ";
       try {
       try (PreparedStatement ps = this.con.prepareStatement(deleteSQL))
       {
           ps.setString(1, string);
           ps.executeUpdate();
       }
       }
       catch(SQLException ex){
       System.out.print("error with delete");
       }
                    }
    
    
    
    public void closeResources() throws SQLException{
    this.con.close();
   
    }
}


