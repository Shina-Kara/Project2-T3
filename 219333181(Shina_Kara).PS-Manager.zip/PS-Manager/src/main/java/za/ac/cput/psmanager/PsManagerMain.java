/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.psmanager;

import java.sql.SQLException;
import za.ac.cput.personnel.domain.PersonnelManager;

/**
 *
 * @author jodykearns
 */
public class PsManagerMain {
    public static void main(String[] args) throws SQLException {
        new PersonnelManager().runPersonnelManager();
        //new InventoryManager().runInventoryManager();
        
    }

}

