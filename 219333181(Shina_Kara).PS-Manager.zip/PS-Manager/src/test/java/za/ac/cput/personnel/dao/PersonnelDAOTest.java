/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.personnel.dao;

import java.sql.SQLException;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import za.ac.cput.psmanager.Personnel.Personnel;

/**
 *
 * @author Shina
 */
public class PersonnelDAOTest {
       
    private PersonnelDAO dao;

       
    public PersonnelDAOTest() {
       
    }
    
    @BeforeAll
    public static void setUpClass() {
        
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() throws SQLException {
        this.dao = new PersonnelDAO();
    }
    
    @AfterEach
    public void tearDown() throws SQLException {
        this.dao.closeResources();
    }

    /**
     * Test of save method, of class StudentDAO.
     * @throws java.lang.Exception
     */
    @Test
    public void testSave() throws Exception {
    
        System.out.println("save");
        Personnel personnel = new Personnel ( "ss", "2" , "3" , "4", "5", "6","7","80","9");
        Personnel expResult = personnel;
        Personnel result = this.dao.save(personnel);
        assertEquals(expResult, result);
    }

    /**
     * Test of getAll method, of class StudentDAO.
     */
    @Test
    public void testGetAll() throws Exception {
        System.out.println("getAll");
         int expResult = 8 ;
        List<Personnel> result = this.dao.getAll();
        assertEquals(expResult, result.size());
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of delete method, of class PersonnelDAO.
     */
    @Test
    public void testDelete() throws SQLException {
        System.out.println("delete");
        String string = "ss";
        this.dao.delete(string);
       
    }

    /**
     * Test of closeResources method, of class PersonnelDAO.
     */
    

   
     
    
}
